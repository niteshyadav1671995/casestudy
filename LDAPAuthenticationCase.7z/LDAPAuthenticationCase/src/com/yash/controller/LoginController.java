package com.yash.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.yash.util.LDAPAccessTest;

@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	LDAPAccessTest ldapAccessTest;

	public LoginController() {
		ldapAccessTest = new LDAPAccessTest();

	}
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String email = req.getParameter("email");
		String password = req.getParameter("password");
		boolean authenticateOrNot = ldapAccessTest.testAuthentication(email, password);
		if (authenticateOrNot) {

			Map<Object, List<Object>> mapofAttributesWithValues = ldapAccessTest.printAllAttributes();
			req.setAttribute("mapofAttributesWithValues", mapofAttributesWithValues);
			req.getRequestDispatcher("success.jsp").forward(req, resp);
		} else {
			resp.sendRedirect("login.jsp?type=error");

		}

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		doGet(req, resp);
	}

}
