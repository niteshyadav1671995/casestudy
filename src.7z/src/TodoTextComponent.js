import React from 'react'

const TodoTextComponent =(props)=>{

        return(
            <li onClick={()=>{props.clicktodo(props.index)}} className={props.todo.completedStatus===true?'completed':''} >{props.todo.todoText}
            <button id="deletebutton" onClick={(event)=>{
                event.stopPropagation();
                props.deleteTodo(props.index)
            }}>X</button>
            </li>
        )
}

export default TodoTextComponent;