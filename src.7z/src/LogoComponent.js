import React from 'react'

const LogoComponent =function(props) {
    return (
        <div>
            <h1>{props.logo}</h1>
        </div>
    )
}

export default LogoComponent;