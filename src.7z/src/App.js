import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import HeaderComponent from './HeaderComponent'
import TodoListComponent from './TodoListComponent'
class App extends Component {
  render() {
    return (
        <div id="container">
          <div id="header">
          <HeaderComponent/>
        
          </div>
          <div id="main">
          <TodoListComponent/>
          </div>
          <div id="footer">
          footer
          </div>
        </div>
    );
  }
}

export default App;
