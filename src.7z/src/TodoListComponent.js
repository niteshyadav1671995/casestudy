import React from 'react'
import TodoFormComponent from './TodoFormComponent'
import TodoTextComponent from './TodoTextComponent'
class TodoListComponent extends React.Component{

    constructor(props){
        super(props);
        this.updateTodo=this.updateTodo.bind(this);
        this.changeTodo=this.changeTodo.bind(this);
        this.addTodo=this.addTodo.bind(this);
        this.state={
            todos:[
                {todoText:"First Todo",completedStatus:false},
                {todoText:"Second Todo",completedStatus:false},
                {todoText:"Third Todo",completedStatus:false},
                {todoText:"Fourth Todo",completedStatus:false},
                {todoText:"Fifth Todo",completedStatus:false}
            ],
            currenttodo:''
        }

    }

    addTodo (event) {
        event.preventDefault();
        let text=this.state.currenttodo;
        let todos=this.state.todos;
        todos.push({
            todoText:text,
            completedStatus:false
        })
        this.setState({
            todos,
            currenttodo:''
        })

    }

    updateTodo (event) {
        this.setState({
             currenttodo:event.target.value
        })
    }

    changeTodo (index) {
        let todos=this.state.todos;
        let todo=todos[index];
        todo.completedStatus=!todo.completedStatus;
        this.setState({
            todos
        })
        console.log(this.state.todos[index]);
        
    }

    deleteTodo=(tobedeleted)=>{
        let todos=this.state.todos;
        todos.splice(tobedeleted,1);
        this.setState({
            todos
        })
    }

    render () {

        return (
            <section>
            <TodoFormComponent currenttodo={this.state.currenttodo} updateTodo={this.updateTodo} addTodo={this.addTodo}/>
            <ul>
                {
                    this.state.todos.map((todo,index)=>{
                        return(
                            <TodoTextComponent key={todo} todo={todo} index={index} deleteTodo={this.deleteTodo} clicktodo={this.changeTodo}/>
                        )
                    })
                }
              
            </ul>
            </section>
        )
    }
}

export default TodoListComponent;