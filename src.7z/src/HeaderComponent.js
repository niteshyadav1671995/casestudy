import React from 'react'
import LogoComponent from './LogoComponent'
class HeaderComponent extends React.Component{
constructor(props){
super(props);
this.state={
    headerText:'TODO-App Using ReactJS'
}
}

    render(){
        return (
            <div>
                <LogoComponent logo="TODO"/>
                <h1>{this.state.headerText}</h1>
            </div>
        )
    }
}

export default HeaderComponent;