import React from 'react'

const TodoFormComponent=(props)=>{
    
    return(
        <div style={{ padding:'20px'}}>
            <form onSubmit={props.addTodo}>
                <input type="text" value={props.currenttodo} onChange={props.updateTodo}/>
                <button type="submit">Add</button>
            </form>
        </div>
    )

}
export default  TodoFormComponent;