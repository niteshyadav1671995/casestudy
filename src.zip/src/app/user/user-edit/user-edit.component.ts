import { Component, OnInit, Input } from '@angular/core';
import {UserService} from '../user.service';
import {Router, ActivatedRoute} from '@angular/router';
import {User} from '../user';

@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.css']
})
export class UserEditComponent implements OnInit {

  private user:User;
  private firstName:string;
  private lastName:string;
  private email:string;

  constructor(private route: ActivatedRoute,private router: Router,private userService: UserService) { }

  ngOnInit() {
  this.getUser();
  }

  getUser() {
    const id = +this.route.snapshot.paramMap.get('id');
    this.userService.findById(id).subscribe(user => this.user = user);

  }

  editUser() {
    if(this.firstName !=null && this.lastName !=null && this.email !=null)
    {
      const id = +this.route.snapshot.paramMap.get('id'); 
    this.user =new User(id,this.firstName,this.lastName,this.email);   
    this.userService.updateUser(this.user).subscribe(user=>{ });
    this.router.navigate(['/']);}
  }



}
