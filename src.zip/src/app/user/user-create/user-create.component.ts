import { Component, OnInit } from '@angular/core';
import {UserService} from '../user.service';
import {Router} from '@angular/router';
import {User} from '../user';
@Component({
  selector: 'app-user-create',
  templateUrl: './user-create.component.html',
  styleUrls: ['./user-create.component.css']
})


export class UserCreateComponent implements OnInit {

  private  user:User;
  private firstName:string;
  private lastName:string;
  private email:string;
  
  constructor(private router: Router,private userService: UserService) { }

  ngOnInit() {
  }

  
  saveUser() {   
   if(this.firstName !=null && this.lastName !=null && this.email !=null)
   {

   this.user =new User(1,this.firstName,this.lastName,this.email);   
   this.userService.saveUser(this.user).subscribe(user=>{ });
   this.router.navigate(['/']);}

  }

}
