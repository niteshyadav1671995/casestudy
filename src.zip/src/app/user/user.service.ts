import { Injectable } from '@angular/core';
import {User} from './user';
import {Http, Response,Headers, HttpModule} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class UserService {

  private apiUrl='http://localhost:8080/users';  
  

  constructor(private http:Http) { }

  findAll():Observable<User[]> {
    return this.http.get(this.apiUrl).map((res:Response) =>res.json());
  }

  findById(id: number): Observable<User> {
    this.apiUrl=this.apiUrl+'/'+id;
    return this.http.get(this.apiUrl).map((res:Response) =>res.json());
  }

  saveUser(user : User) {
    let headers = new Headers(
      {
        'Content-Type': 'application/json'
        
      });
    return this.http.post(this.apiUrl,user);
  }

  deleteUserById(id: number) {
    let headers = new Headers(
      {
        'Content-Type': 'application/json'
        
      });
      this.apiUrl=this.apiUrl+'/'+id;
    return this.http.delete(this.apiUrl,{headers:headers} );
  }
 
  updateUser(user: User) {
    return this.http.put(this.apiUrl,user);
  }


}
