import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { User } from './user';
@Injectable()
export class UserService {

  constructor(private http:Http) { }

  getUsers(){
    let url='http://localhost:8080/issueweb/users';
    
    return this.http.get(url);
  }

  registerUser(user:User){
    console.log(user);
    let url='http://localhost:8080/issueweb/users/add';
    let headers = new Headers(
      {
        'Content-Type':'application/json'
      });
    return this.http.post(url, user ,{headers: headers, withCredentials:true});
  }

  deleteUser(id:Number){
    console.log(id);
    let url='http://localhost:8080/issueweb/users/'+id;
    let headers = new Headers(
      {
        'Content-Type':'application/json'
      });
    return this.http.delete(url,{headers: headers, withCredentials:true});
  }

  getUserById(id:number){
    console.log(id);
    let url='http://localhost:8080/issueweb/users/'+id;
    let headers = new Headers(
      {
        'Content-Type':'application/json'
      });
    return this.http.get(url,{headers: headers, withCredentials:true});
  }

  updateUser(user:User){
    let url='http://localhost:8080/issueweb/users/edit';
    let headers = new Headers(
      {
        'Content-Type':'application/json'
      });
      return this.http.put(url,user,{headers:headers, withCredentials:true});
  }

}
