import { Component, OnInit } from '@angular/core';
import{User} from '../user';
import {UserService } from '../user.service';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  ngOnInit() {
  }
  user=new User();
  constructor(private userService:UserService) { }

  register(){
    this.userService.registerUser(this.user).subscribe(
    res=>{
      console.log(res);
    },
    err=>{
      console.log(err);
    }
  
);

  
  }
}
