import { Injectable } from '@angular/core';
import { Observable} from 'rxjs/Observable';
import { Http, Headers} from '@angular/http';

@Injectable()
export class LoginService {

  constructor(private http: Http) { }

  sendCredential(login_name: string, password: string) {
    let url='http://localhost:8080/issueweb/user/login';
    let user={
        'login_name':login_name,
        'password':password
    };
    let headers = new Headers({
      'Content-Type':'application/json'
    });
    return this.http.post(url,user,{headers : headers, withCredentials : true});
  }


}
