import { Component, OnInit } from '@angular/core';
import {UserService } from '../user.service';
import { User } from '../user';


@Component({
  selector: 'app-user-crud',
  templateUrl: './user-crud.component.html',
  styleUrls: ['./user-crud.component.css']
})
export class UserCrudComponent implements OnInit {

  editableUser:User;
  users:User[];
  user=new User();
  id:number;
  constructor(private userService:UserService) { }

  ngOnInit() {
  }

  getUserById(){
    console.log(this.id);
    this.userService.getUserById(this.id).subscribe(
      res=>{
        console.log(res);
        console.log(this. editableUser);
        this.editableUser=JSON.parse(JSON.parse(JSON.stringify(res))._body);
      },
      err=>{
        console.log(err);
      }
    );

  }

  update(){
    this.userService.updateUser(this.editableUser).subscribe(
      res=>{
        console.log(res);
      },
      err=>{
        console.log(err);
      }
    );
  }
getUsers() : void {
  this.userService.getUsers().subscribe(
    res => {
      this.users=JSON.parse(JSON.parse(JSON.stringify(res))._body);
      console.log(res.text());
    }
  );
}

delete(){
this.userService.deleteUser(this.id).subscribe(
  res=>{
    console.log(res);
  },
  err=>{
    console.log(err);
  }
);
}
}

