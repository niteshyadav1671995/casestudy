import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import {Observable} from 'rxjs/Observable';
import {LoginService} from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user:User;
  login_name:string;
  password:string;
  constructor(private loginService: LoginService) { }

 
onSubmit(){
this.loginService.sendCredential(this.login_name, this.password).subscribe(
  res=>{
      this.user=JSON.parse(JSON.parse(JSON.stringify(res))._body);
    console.log(res);
    console.log(this.user);
  },
  err=>{
    console.log(err);
  }
);
}
ngOnInit() {
}
}
